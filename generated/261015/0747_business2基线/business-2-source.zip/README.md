---
title: DecAgent — 员工身份与可恢复业务执行
type: explanation
audience: [A1, A2, A3, A4, A5]
runs: no
verified_on: 2026-10-14
sources: [decagent/business, decagent/gateway, decagent/runtime, decagent/storage, ops/local/start.py]
---
# DecAgent

DecAgent 是基于 LangGraph 的业务 Agent，通过 **MCP + Skill** 接入业务能力。
主模型处理复杂规划，Jev 提供有限选项的类型化判断，
程序管理员工权限、人工介入、预算、持久状态与可核实回执。

项目关注的是：什么时候可以继续，什么时候需要补充事实或具体确认，
以及发生超时、重启和并发时如何判断业务是否真的完成。
当前内置本地模拟服务工单，包含创建、分配、处理、解决、关闭和重开。
员工、处理人和主管使用不同权限；未接入御龙后端或真实公司业务 API。
仓库修复保留在独立入口。

## 使用与理解

- [使用指南](generated/261014/1646_MCP业务Agent使用指南.md)：环境、启动、员工登录、第一条任务、多角色操作与恢复。
- [架构详解](generated/261014/1646_MCP业务Agent架构详解.md)：组件、流程、泳道、时序、事务恢复、实体关系和 Jev 三类判断。
- [离线交互图册](generated/261014/1646_MCP业务Agent架构图册.html)：切换视图、缩放、查看说明及导出 SVG。
- [源码与逐脚本职责](generated/261014/1646_MCP源码结构与脚本职责.md)：149 个产品/运维脚本与 120 个测试/验收脚本索引。
- [本机运维与恢复](generated/261014/1646_MCP本机运维与恢复.md)：端口、停止顺序、迁移、历史数据与回滚范围。
- [员工账号与权限](generated/261013/1623_模拟员工账号与权限指南.md)、
  [独立 MCP 调用](generated/261013/2050_MCP命令行调用指南.md)、
  [操作恢复细则](generated/261013/2039_业务操作恢复与核实指南.md)。

默认 [员工工作台](http://127.0.0.1:8000/) 使用员工登录；
[仓库修复与运维](http://127.0.0.1:8000/repair) 使用原 owner 身份。
源码在 decagent、ops、evals；生成材料在 generated/YYMMDD；私有运行数据在 .decagent。

- [本机验收记录](generated/261014/2252_MCP本机验收记录.md)：1231 项最终适用测试、安装包和本机服务证据。
- [需求测试对应表](generated/261014/2213_MCP需求测试对应表.md)：六项能力、34 条需求与 66 个场景逐条关联。

## 当前实现

| 边界 | 实现 |
| --- | --- |
| 业务协议 | 官方 MCP SDK 2.3.0；主协议 2026-07-28，兼容 2025-11-25 |
| 业务能力 | service-tickets 2.0.0；12 个领域命令，14 个网络工具 |
| 员工身份 | 固定任务员工；12 小时浏览器会话、1 小时独立 MCP token |
| 具体确认 | 原员工网页批准；15 分钟有效期；编辑产生新操作 |
| 写入一致性 | 不可变 prepare；commit 重查权限；工单/历史/回执同事务 |
| 异常恢复 | 先查询原 operation_id；核实回执后决定原 ID 是否可恢复 |
| Agent 约束 | 隐藏 grant 绑定任务、动作、预算、契约、员工和租约代次 |
| 持久执行 | business-2 LangGraph、PostgreSQL checkpoint、schema 11 |

LLM 只能提出注册命令与业务参数。Jev 的分支、命题与评分尺来自程序和版本化契约，
动态候选来自实际 MCP 查询；模型不能改写权限或自我批准。
业务 CLI 执行入口已移除，本地管理 CLI 继续负责初始化、注册和运维。

## 验证与限制

[本机启动烟测](generated/261014/1646_MCP本机启动烟测.json)已经验证员工任务通过 MCP
产生一个成功操作和一张回执，模型调用为 0，历史匿名工单与 owner 保留。
[固定多角色验收](generated/261014/1649_MCP多角色业务验收.json)为 11/11，
禁止的业务副作用为 0；包含并发重复提交、模拟响应丢失与真实服务重启。
脚本验收中的机器耗时与人工等待分别记录，不代表真实模型性能或企业提效。

新 MCP 契约尚无验收通过的 Jev 校准配置。hybrid 在缺少兼容校准时转交主模型。
旧 CLI/Jev 对照绑定旧源码与数据集，不能用于证明当前 MCP 版本加速。
独立 Linux 主机部署仍待验收，本机 Docker Desktop 测试不替代该项。

## 历史证据

- [旧 CLI 业务使用指南](generated/261012/0852_业务Agent使用指南.md)
  与[旧架构](generated/261012/0852_业务Agent架构详解.md)仅供历史比对。
- [旧 720 次业务对照](generated/261012/2341_业务固定集完整实测.md)严格验收未通过：
  7 个 trial 用量不完整；当时全部 Jev 快路线禁用，无提效结论。
- [旧修复与 9 次真实功能验证](generated/261013/0158_现版本修复与功能验证.md)
  保留当时版本的证据范围。
- [旧仓库修复指南](generated/261011/0616_使用指南.md)
  与[GitHub 验收](generated/261011/0643_GitHub与真实验收记录.md)保留独立任务能力记录。

当前 OpenSpec change 位于同级 12-hermes-agent-small/openspec/changes/mcp-business-runtime。
历史 change 和评测数据保留，本轮不自动归档。来源与许可见 LICENSE 和 NOTICE。

