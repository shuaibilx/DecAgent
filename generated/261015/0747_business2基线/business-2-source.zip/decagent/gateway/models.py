"""Closed input DTOs; provenance and operative snapshots never come from requests."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class SessionInput(Input):
    token: str = Field(min_length=32, max_length=512, repr=False)


class EmployeeLoginInput(Input):
    login: str = Field(pattern=r"^[a-z][a-z0-9-]{0,63}$")
    password: str = Field(min_length=1, max_length=512, repr=False)


class BusinessOperationReplyInput(Input):
    expected_hash: str = Field(pattern=r"^[a-f0-9]{64}$")
    decision: Literal["approve", "reject", "edit"]
    edited_params: dict | None = None


class ProjectInput(Input):
    repository: str = Field(pattern=r"^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$", max_length=200)
    base_branch: str = Field(default="main", min_length=1, max_length=200)


class BudgetInput(Input):
    max_calls: int = Field(default=30, ge=1, le=100000)
    max_tokens: int = Field(default=100000, ge=1, le=100000000)
    max_active_seconds: int = Field(default=1800, ge=1, le=86400)
    max_cost: str | None = Field(default=None, max_length=30)
    allow_unknown_price: bool = False


class TrustInput(Input):
    kind: Literal["exact_commit", "own_branch"] = "exact_commit"
    branch: str | None = Field(default=None, max_length=200)


class TaskInput(Input):
    project_id: str
    base_ref: str = Field(min_length=1, max_length=200)
    issue: str = Field(min_length=1, max_length=65536)
    trust_scope: TrustInput | None = None
    budget: BudgetInput = Field(default_factory=BudgetInput)
    publish_draft_pr: bool = False


class BusinessTaskInput(Input):
    scope_id: str = Field(min_length=36, max_length=36)
    instruction: str = Field(min_length=1, max_length=65536)
    strategy: Literal["rule", "main", "hybrid"] = "hybrid"
    budget: BudgetInput = Field(default_factory=BudgetInput)


class ResumeInput(Input):
    budget: BudgetInput | None = None


class ReplyInput(Input):
    expected_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    decision: Literal["approve", "reject", "edit", "confirm"]
    edited_params: dict | None = None
    confirmation: str | None = Field(default=None, min_length=1, max_length=65536)


class ResponseInput(Input):
    question_id: str
    expected_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    content: str = Field(min_length=1, max_length=65536)


class DiagnosticInput(Input):
    mode: Literal["local", "live"] = "local"
    target: Literal["main", "jev", "github", "executor"] | None = None
    confirm_external_request: bool = False


class MemoryReviewInput(Input):
    operation: Literal["activate", "reject"]
    confirmation_id: str | None = None
    confirmation: str | None = Field(default=None, min_length=1, max_length=65536)
    expected_revision: int = Field(ge=1)


class MemoryRevokeInput(Input):
    expected_revision: int = Field(ge=1)
