"use strict";

const $ = id => document.getElementById(id);
const state = {
  csrf: sessionStorage.getItem("decagent.employee.csrf") || "",
  identity: null, plugins: [], task: null, operation: null,
  selection: 0, operationSelection: 0, stream: null, cursor: new Map(),
  credentialRef: null, refreshTimer: null,
};
const terminal = new Set(["succeeded", "failed", "cancelled"]);
const taskLabels = {queued: "排队中", running: "执行中", awaiting_input: "等待补充",
  awaiting_approval: "等待确认", paused_budget: "预算暂停", recovering: "等待核实",
  succeeded: "目标已完成", failed: "未完成", cancelled: "已取消"};
const operationLabels = {ready: "待提交", awaiting_approval: "待本人确认", running: "执行中",
  unknown: "结果待核实", succeeded: "已核实成功", failed: "失败", rejected: "已拒绝",
  expired: "确认失效", cancelled: "已取消"};
const phaseLabels = {prepare: "查证事实", decide: "判断分支", plan: "规划步骤",
  validate: "校验动作", human: "人工决定", execute: "执行操作",
  verify: "核实回执", finalize: "核实目标"};

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}
function notice(message) { $("notice").textContent = message; $("notice").hidden = !message; }
function details(label, value) {
  const wrapper = el("details");
  wrapper.append(el("summary", label), el("pre", JSON.stringify(value, null, 2)));
  return wrapper;
}
function resetWorkspace(clearHash = true) {
  clearTimeout(state.refreshTimer);
  state.selection++; state.operationSelection++;
  state.stream?.close(); state.stream = null;
  state.cursor.clear(); state.task = null; state.operation = null;
  state.identity = null; state.plugins = []; state.credentialRef = null;
  $("task-list").replaceChildren(); $("ticket-list").replaceChildren();
  $("ticket-detail").replaceChildren(); $("operation-list").replaceChildren();
  $("operation-detail").hidden = true; $("credential-info").replaceChildren();
  $("plugin-select").replaceChildren(); $("capabilities").replaceChildren();
  $("plugin-description").textContent = ""; $("submit-task").disabled = true;
  for (const id of ["task-instruction", "phases", "waiting", "approvals", "result",
    "actions", "decisions", "events", "operation-body", "operation-actions"]) $(id).replaceChildren();
  $("task-title").textContent = "选择一个任务"; $("task-state").textContent = "—";
  $("connection").textContent = "进度尚未连接";
  $("cancel-task").hidden = true; $("resume-task").hidden = true;
  $("budget-form").hidden = true; $("waiting").hidden = true;
  $("revoke-credential").hidden = true; $("current-identity").hidden = true;
  $("current-identity").textContent = "";
  $("workbench").hidden = true; $("logout").hidden = true; $("login-panel").hidden = false;
  if (clearHash && location.hash.startsWith("#operation=")) {
    history.replaceState(null, "", location.pathname);
  }
}
async function api(path, {method = "GET", body, key} = {}) {
  const headers = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (method !== "GET") {
    headers["X-CSRF-Token"] = state.csrf;
    headers["Idempotency-Key"] = key || crypto.randomUUID();
  }
  const response = await fetch("/api/v2/business" + path, {
    method, headers, credentials: "same-origin",
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) {
    if (response.status === 401) {
      sessionStorage.removeItem("decagent.employee.csrf");
      state.csrf = ""; resetWorkspace();
    }
    throw new Error(`${result.code || "request_failed"}: ${result.message || "请求失败"}`);
  }
  return result;
}
function bind(id, event, callback) {
  $(id).addEventListener(event, async e => {
    if (event === "submit") e.preventDefault();
    try { notice(""); await callback(e); } catch (error) { notice(error.message); }
  });
}
function describePlugin() {
  const plugin = state.plugins.find(item => item.scope_id === $("plugin-select").value);
  $("plugin-description").textContent = plugin
    ? `${plugin.plugin_id} · ${plugin.version} · ${plugin.commands.length} 项当前角色可用能力`
    : "尚无可用业务插件，请由实例维护者登记。";
  $("submit-task").disabled = !plugin;
}
async function loadPlugins() {
  state.plugins = await api("/plugins");
  $("plugin-select").replaceChildren(); $("capabilities").replaceChildren();
  for (const plugin of state.plugins) {
    const option = el("option", `${plugin.plugin_id} · ${plugin.version}`);
    option.value = plugin.scope_id; $("plugin-select").append(option);
    const section = el("section"); section.append(el("h3", plugin.plugin_id));
    const list = el("ul");
    for (const command of plugin.commands) {
      list.append(el("li", `${command.name} · ${command.effect === "read" ? "查询" : "写入"} · ${command.description}`));
    }
    section.append(list); $("capabilities").append(section);
  }
  describePlugin();
}
async function loadTasks() {
  const tasks = await api("/tasks");
  $("task-list").replaceChildren();
  if (!tasks.length) $("task-list").append(el("p", "当前员工没有任务。", "muted"));
  for (const task of tasks) {
    const button = el("button", `${taskLabels[task.state] || task.state} · ${task.id.slice(0, 8)}\n${(task.requested_issue || "").slice(0, 80)}`,
      state.task?.id === task.id ? "active" : "");
    button.type = "button";
    button.addEventListener("click", () => selectTask(task.id).catch(error => notice(error.message)));
    $("task-list").append(button);
  }
}
async function selectTask(id) {
  const sequence = ++state.selection;
  state.stream?.close(); state.stream = null;
  const task = await api(`/tasks/${id}`);
  if (sequence !== state.selection) return;
  state.task = task; renderTask(task); await loadTasks(); connectEvents(id, sequence);
}
function renderTask(task) {
  $("task-title").textContent = `任务 ${task.id.slice(0, 8)}`;
  $("task-state").textContent = `${taskLabels[task.state] || task.state} · ${phaseLabels[task.phase] || task.phase}`;
  $("task-instruction").textContent = task.requested_issue || "";
  $("phases").replaceChildren();
  for (const [phase, text] of Object.entries(phaseLabels)) {
    $("phases").append(el("li", text, task.phase === phase ? "current" : ""));
  }
  const waiting = !terminal.has(task.state) && !["queued", "running"].includes(task.state);
  $("waiting").hidden = !waiting;
  $("waiting").textContent = waiting
    ? (task.waiting?.payload?.question || task.waiting?.payload?.reason || taskLabels[task.state] || task.state)
    : "";
  $("cancel-task").hidden = terminal.has(task.state);
  $("resume-task").hidden = task.state !== "recovering";
  $("budget-form").hidden = task.state !== "paused_budget";
  $("resume-calls").value = task.budget.max_calls || 30;
  $("resume-tokens").value = task.budget.max_tokens || 100000;
  $("resume-active").value = task.budget.max_active_seconds || 1800;
  $("resume-cost").value = task.budget.max_cost || "";
  $("approvals").replaceChildren();
  const pending = (task.approvals || []).filter(item => item.status === "pending");
  if (!pending.length) $("approvals").append(el("p", "当前没有待处理的问题。", "muted"));
  for (const approval of pending) renderTaskApproval(task, approval);
  $("result").replaceChildren();
  if (task.business_result) $("result").append(details("目标核实", task.business_result));
  $("actions").replaceChildren();
  for (const action of task.actions || []) {
    const card = el("section", undefined, "receipt");
    card.append(el("h3", `${action.snapshot?.command || "操作"} · ${action.status}`),
      details("参数与回执", {action_id: action.id, snapshot: action.snapshot, receipt: action.receipt}));
    $("actions").append(card);
  }
  $("decisions").replaceChildren();
  if (!task.decisions?.length) $("decisions").append(el("p", "尚无模型判断记录。", "muted"));
  for (const record of task.decisions || []) {
    const card = el("section", undefined, "route");
    card.append(el("h3", `${record.question_version === "primary-plan-1" ? "主模型规划" : "类型化判断"} · ${record.final_route}`),
      details("实际问题与答案", record.result));
    $("decisions").append(card);
  }
}
function renderTaskApproval(task, approval) {
  const card = el("section", undefined, "approval-card");
  const action = approval.action || {};
  const isAction = approval.kind === "action";
  const operationId = (task.actions || []).find(item => item.id === approval.action_id)
    ?.server_operation_id;
  card.append(
    el("h3", isAction ? `确认具体业务操作 · ${action.command || "待执行"}` : "补充业务信息"),
    el("p", `确认摘要：${approval.digest} · 版本：${approval.version}`, "muted"),
  );
  if (isAction) {
    card.append(details("冻结动作参数与服务端操作", {
      action, operation_id: operationId, approval_id: approval.id,
    }));
    if (operationId) {
      const linked = el("button", "查看关联操作", "quiet"); linked.type = "button";
      linked.addEventListener("click", () => selectOperation(operationId)
        .catch(error => notice(error.message)));
      card.append(linked);
    }
  } else {
    card.append(el("p", approval.reply_payload?.question || task.waiting?.payload?.question
      || "请提供完成当前业务步骤所需的信息。"));
  }
  const controls = el("div", undefined, "approval-controls");
  const send = async (decision, extra = {}) => {
    if (state.task?.id !== task.id) return;
    for (const button of controls.querySelectorAll("button")) button.disabled = true;
    try {
      await api(`/tasks/${task.id}/approvals/${approval.id}/reply`, {
        method: "POST", body: {expected_digest: approval.digest, decision, ...extra},
      });
      notice("本人决定已保存；Agent 将按当前回复继续处理。");
      await selectTask(task.id);
      await loadOperations();
    } catch (error) {
      notice(error.message);
      for (const button of controls.querySelectorAll("button")) button.disabled = false;
    }
  };
  const reject = el("button", "拒绝", "danger"); reject.type = "button";
  reject.addEventListener("click", () => send("reject"));
  if (isAction) {
    const approve = el("button", "批准当前冻结参数"); approve.type = "button";
    approve.addEventListener("click", () => send("approve"));
    const editor = el("textarea"); editor.rows = 5;
    editor.setAttribute("aria-label", "编辑完整业务操作参数 JSON");
    editor.value = JSON.stringify(action.params || {}, null, 2);
    const edit = el("button", "修改并重新规划"); edit.type = "button";
    edit.addEventListener("click", () => {
      try { send("edit", {edited_params: JSON.parse(editor.value)}); }
      catch { notice("请填写有效的完整 JSON 参数。"); }
    });
    controls.append(approve, reject, editor, edit);
  } else {
    const answer = el("textarea"); answer.rows = 3;
    answer.setAttribute("aria-label", "补充业务信息");
    const confirm = el("button", "提交补充信息"); confirm.type = "button";
    confirm.addEventListener("click", () => {
      if (!answer.value.trim()) { notice("请填写具体补充信息。"); return; }
      send("confirm", {confirmation: answer.value.trim()});
    });
    controls.append(answer, confirm, reject);
  }
  card.append(controls); $("approvals").append(card);
}
function connectEvents(id, sequence) {
  const cursor = state.cursor.get(id) || 0;
  $("events").replaceChildren();
  state.stream = new EventSource(`/api/v2/business/tasks/${id}/events?after=${cursor}`);
  state.stream.onopen = () => { $("connection").textContent = "实时进度已连接"; };
  state.stream.onerror = () => { $("connection").textContent = "进度连接中断，正在重新连接"; };
  state.stream.addEventListener("task_event", event => {
    if (sequence !== state.selection || state.task?.id !== id) return;
    const item = JSON.parse(event.data);
    if (item.seq <= (state.cursor.get(id) || 0)) return;
    state.cursor.set(id, item.seq);
    $("events").append(el("li", `${item.seq} · ${item.kind} · ${JSON.stringify(item.payload)}`));
    clearTimeout(state.refreshTimer);
    state.refreshTimer = setTimeout(() => {
      if (sequence === state.selection) selectTask(id).catch(error => notice(error.message));
    }, 150);
  });
}
async function loadTickets() {
  const result = await api("/tickets");
  $("ticket-list").replaceChildren();
  if (!result.tickets.length) $("ticket-list").append(el("p", "没有当前身份可访问的工单。", "muted"));
  for (const ticket of result.tickets) {
    const button = el("button", `${ticket.status} · ${ticket.title}\n${ticket.id.slice(0, 8)} · revision ${ticket.revision}`);
    button.type = "button";
    button.addEventListener("click", () => selectTicket(ticket.id).catch(error => notice(error.message)));
    $("ticket-list").append(button);
  }
}
async function selectTicket(id) {
  const result = await api(`/tickets/${id}`);
  $("ticket-detail").replaceChildren(
    el("h3", `${result.ticket.title} · ${result.ticket.status}`),
    details("工单及授权历史", result),
  );
}
async function loadOperations() {
  const operations = await api("/operations");
  $("operation-list").replaceChildren();
  if (!operations.length) $("operation-list").append(el("p", "没有可查看的操作。", "muted"));
  for (const operation of operations) {
    const source = operation.source === "external_mcp" ? "独立 MCP" : "DecAgent";
    const button = el("button", `${operationLabels[operation.state] || operation.state} · ${operation.command} · ${source}\n${operation.operation_id}`,
      state.operation?.operation_id === operation.operation_id ? "active" : "");
    button.type = "button";
    button.addEventListener("click", () => selectOperation(operation.operation_id).catch(error => notice(error.message)));
    $("operation-list").append(button);
  }
}
async function selectOperation(id) {
  const sequence = ++state.operationSelection;
  const operation = await api(`/operations/${encodeURIComponent(id)}`);
  if (sequence !== state.operationSelection) return;
  state.operation = operation; renderOperation(operation); await loadOperations();
}
function renderOperation(operation) {
  $("operation-detail").hidden = false;
  $("operation-title").textContent = `${operation.command} · ${operationLabels[operation.state] || operation.state}`;
  $("operation-body").replaceChildren(); $("operation-actions").replaceChildren();
  const source = operation.source === "external_mcp" ? "独立 MCP 客户端" : "DecAgent";
  $("operation-body").append(
    el("p", `来源：${source} · 原操作 ID：${operation.operation_id}`),
    el("p", `员工：${operation.employee_id} · 准备时 revision：${operation.expected_revision ?? "新建"}`),
    details("冻结参数、输入摘要与资源快照", {
      params: operation.params, input_hash: operation.input_hash,
      resource_snapshot: operation.resource_snapshot, supersedes: operation.supersedes,
      approval_expires_at: operation.approval_expires_at,
    }),
  );
  if (operation.state === "succeeded" && operation.result) {
    $("operation-body").append(details("已核实业务结果与回执", operation.result));
  } else if (operation.state === "unknown" || operation.state === "running") {
    $("operation-body").append(el("p", "执行结果尚不确定。只查询这个原操作 ID，不创建新操作重试。", "muted"));
  } else if (operation.state === "ready" && operation.source === "external_mcp") {
    $("operation-body").append(el("p", "确认已记录。请回到原 MCP 客户端，用同一 operation_id 提交。", "muted"));
  }
  if (operation.error_code) $("operation-body").append(el("p", `原因：${operation.error_code}`, "failed"));
  const verify = el("button", "核实原操作 ID", "quiet"); verify.type = "button";
  verify.addEventListener("click", () => selectOperation(operation.operation_id).catch(error => notice(error.message)));
  $("operation-actions").append(verify);
  if (operation.state !== "awaiting_approval" || operation.employee_id !== state.identity.employee_id) return;
  const text = el("textarea"); text.rows = 5; text.value = JSON.stringify(operation.params, null, 2);
  text.setAttribute("aria-label", "编辑操作完整参数");
  $("operation-actions").append(el("p", "请核对参数和 revision。编辑将产生新操作，并要求重新确认。"), text);
  for (const [decision, label] of [["approve", "批准"], ["reject", "拒绝"], ["edit", "编辑并重新准备"]]) {
    const button = el("button", label, decision === "reject" ? "danger" : ""); button.type = "button";
    button.addEventListener("click", async () => {
      button.disabled = true;
      try {
        const body = {expected_hash: operation.input_hash, decision};
        if (decision === "edit") body.edited_params = JSON.parse(text.value);
        const updated = await api(`/operations/${encodeURIComponent(operation.operation_id)}/reply`, {method: "POST", body});
        notice(decision === "edit" ? "已创建新操作，请重新核对并确认。" : "决定已记录；实际业务提交仍需原操作核实。" );
        await selectOperation(updated.operation_id);
      } catch (error) { notice(error.message); } finally { button.disabled = false; }
    });
    $("operation-actions").append(button);
  }
}
async function enter() {
  const identity = await api("/auth/session");
  resetWorkspace(false); state.identity = identity;
  $("current-identity").textContent = `${identity.login} · ${identity.role}`;
  $("current-identity").hidden = false;
  $("login-panel").hidden = true; $("workbench").hidden = false; $("logout").hidden = false;
  const outcomes = await Promise.allSettled([loadPlugins(), loadTasks(), loadTickets(), loadOperations()]);
  const failed = outcomes.filter(item => item.status === "rejected");
  if (failed.length) notice(`${failed.length} 个业务视图暂不可用：${failed[0].reason.message}`);
  const selected = new URLSearchParams(location.hash.slice(1)).get("operation");
  if (selected) await selectOperation(selected);
}

bind("login-form", "submit", async () => {
  const response = await fetch("/api/v2/business/auth/session", {
    method: "POST", headers: {"Content-Type": "application/json"}, credentials: "same-origin",
    body: JSON.stringify({login: $("employee-login").value.trim(), password: $("employee-password").value}),
  });
  $("employee-password").value = "";
  const result = await response.json();
  if (!response.ok) throw new Error(`${result.code}: ${result.message}`);
  state.csrf = result.csrf_token;
  sessionStorage.setItem("decagent.employee.csrf", state.csrf);
  await enter();
});
bind("logout", "click", async () => {
  await api("/auth/session", {method: "DELETE"});
  sessionStorage.removeItem("decagent.employee.csrf"); state.csrf = "";
  resetWorkspace();
});
bind("plugin-select", "change", describePlugin);
bind("refresh", "click", async () => { await loadTasks(); if (state.task) await selectTask(state.task.id); });
bind("refresh-tickets", "click", loadTickets);
bind("refresh-operations", "click", async () => {
  await loadOperations(); if (state.operation) await selectOperation(state.operation.operation_id);
});
bind("business-form", "submit", async () => {
  const button = $("submit-task"); button.disabled = true;
  try {
    const body = {scope_id: $("plugin-select").value, instruction: $("instruction").value,
      strategy: $("strategy").value, budget: {max_calls: Number($("max-calls").value),
        max_tokens: Number($("max-tokens").value), max_active_seconds: Number($("max-active").value),
        max_cost: $("max-cost").value.trim() || null}};
    const task = await api("/tasks", {method: "POST", body});
    await selectTask(task.id);
  } finally { button.disabled = false; }
});
bind("cancel-task", "click", async () => {
  const id = state.task.id; await api(`/tasks/${id}/cancel`, {method: "POST", body: {}});
  await selectTask(id);
});
bind("resume-task", "click", async () => {
  const id = state.task.id; await api(`/tasks/${id}/resume`, {method: "POST", body: {}});
  await selectTask(id);
});
bind("budget-form", "submit", async () => {
  const id = state.task.id;
  const budget = {...state.task.budget, max_calls: Number($("resume-calls").value),
    max_tokens: Number($("resume-tokens").value), max_active_seconds: Number($("resume-active").value),
    max_cost: $("resume-cost").value.trim() || null};
  await api(`/tasks/${id}/resume`, {method: "POST", body: {budget}});
  await selectTask(id);
});
bind("issue-credential", "click", async () => {
  const credential = await api("/auth/mcp-credentials", {method: "POST"});
  state.credentialRef = credential.credential_ref;
  $("credential-info").replaceChildren(el("p", `凭据引用：${credential.credential_ref}`),
    el("p", `受保护文件：${credential.credential_path}`), el("p", `到期：${credential.expires_at}`));
  $("revoke-credential").hidden = false;
});
bind("revoke-credential", "click", async () => {
  await api(`/auth/mcp-credentials/${state.credentialRef}`, {method: "DELETE"});
  state.credentialRef = null; $("credential-info").replaceChildren();
  $("revoke-credential").hidden = true;
});
if (state.csrf) enter().catch(error => { resetWorkspace(); notice(error.message); });
