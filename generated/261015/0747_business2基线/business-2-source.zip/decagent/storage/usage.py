"""Durable budget ledger. Serialize reservations under the task row lock before each request."""

import math
from decimal import Decimal
from uuid import uuid4

from decagent.storage.budget import BudgetExceeded


class UsageLedger:
    def __init__(self, database, task_id):
        self.database = database
        self.task_id = task_id

    def charge_active(self, seconds):
        if type(seconds) not in (int, float) or not math.isfinite(seconds) or seconds < 0:
            raise ValueError("Active duration must be nonnegative")
        with self.database.connect() as conn:
            # Owner/human waits do not consume active execution time.
            row = conn.execute(
                "UPDATE app.tasks SET active_seconds=active_seconds+%s WHERE id=%s "
                "AND state IN ('running','recovering') RETURNING active_seconds",
                (seconds, self.task_id),
            ).fetchone()
            return row["active_seconds"] if row else None

    @staticmethod
    def _held_usage(rows):
        tokens = sum(
            r["actual_tokens"]
            if r["status"] == "settled"
            else max(r["requested_tokens"], r["actual_tokens"] or 0)
            for r in rows
        )
        cost = sum(
            (
                r["actual_cost"]
                if r["status"] == "settled"
                else max(r["reserved_cost"] or Decimal("0"), r["actual_cost"] or Decimal("0"))
                for r in rows
            ),
            Decimal("0"),
        )
        return tokens, cost

    def assert_available(self, *, connection=None):
        """Require remaining durable budget before starting a new non-model action.

        Pass the action transaction's connection to keep this check and its running
        transition under the same task row lock. Receipt reconciliation is exempt.
        """
        if connection is None:
            with self.database.connect() as conn:
                return self.assert_available(connection=conn)
        task = connection.execute(
            "SELECT * FROM app.tasks WHERE id=%s FOR UPDATE", (self.task_id,)
        ).fetchone()
        if not task:
            raise KeyError("Task not found")
        rows = connection.execute(
            "SELECT * FROM app.usage_records WHERE task_id=%s", (self.task_id,)
        ).fetchall()
        tokens, cost = self._held_usage(rows)
        bounds = task["budget"]
        if len(rows) >= bounds.get("max_calls", 30):
            raise BudgetExceeded("Call budget exhausted before action")
        if tokens >= bounds.get("max_tokens", 100_000):
            raise BudgetExceeded("Token budget exhausted before action")
        if task["active_seconds"] >= bounds.get("max_active_seconds", 1800):
            raise BudgetExceeded("Active task time exhausted before action")
        limit = bounds.get("max_cost")
        if limit is not None and cost >= Decimal(str(limit)):
            raise BudgetExceeded("Cost budget exhausted before action")

    def reserve(self, key, attempt, provider, tokens, cost, allow_unknown_price=False):
        if tokens <= 0 or attempt < 0 or (cost is not None and (not cost.is_finite() or cost < 0)):
            raise ValueError("Invalid usage reservation")
        with self.database.connect() as conn:
            task = conn.execute(
                "SELECT * FROM app.tasks WHERE id=%s FOR UPDATE", (self.task_id,)
            ).fetchone()
            if not task:
                raise KeyError("Task not found")
            prior = conn.execute(
                "SELECT * FROM app.usage_records WHERE task_id=%s AND reservation_key=%s "
                "AND attempt=%s",
                (self.task_id, key, attempt),
            ).fetchone()
            if prior:
                if (
                    prior["requested_tokens"] != tokens
                    or prior["reserved_cost"] != cost
                    or prior["provider"] != provider
                ):
                    raise ValueError("Reservation key reused for different request")
                return prior["id"]
            bounds = task["budget"]
            if cost is None and not (allow_unknown_price and bounds.get("allow_unknown_price")):
                raise BudgetExceeded("Unknown price requires owner-authorized bounded calls")
            rows = conn.execute(
                "SELECT * FROM app.usage_records WHERE task_id=%s", (self.task_id,)
            ).fetchall()
            held_tokens, held_cost = self._held_usage(rows)
            if len(rows) >= bounds.get("max_calls", 30):
                raise BudgetExceeded("Call budget exhausted before request")
            if held_tokens + tokens > bounds.get("max_tokens", 100_000):
                raise BudgetExceeded("Token budget exhausted before request")
            if task["active_seconds"] >= bounds.get("max_active_seconds", 1800):
                raise BudgetExceeded("Active task time exhausted")
            limit = bounds.get("max_cost")
            if limit is not None and cost is not None and held_cost + cost > Decimal(str(limit)):
                raise BudgetExceeded("Cost budget exhausted before request")
            row = conn.execute(
                "INSERT INTO app.usage_records"
                "(id,task_id,reservation_key,attempt,provider,requested_tokens,reserved_cost) "
                "VALUES(%s,%s,%s,%s,%s,%s,%s) RETURNING id",
                (uuid4(), self.task_id, key, attempt, provider, tokens, cost),
            ).fetchone()
            return row["id"]

    def settle(self, receipt_id, tokens, cost):
        if tokens is not None and tokens < 0:
            raise ValueError("Usage cannot be negative")
        if cost is not None and (not cost.is_finite() or cost < 0):
            raise ValueError("Cost must be nonnegative and finite")
        with self.database.connect() as conn:
            conn.execute("SELECT id FROM app.tasks WHERE id=%s FOR UPDATE", (self.task_id,))
            row = conn.execute(
                "SELECT * FROM app.usage_records WHERE id=%s AND task_id=%s FOR UPDATE",
                (receipt_id, self.task_id),
            ).fetchone()
            if not row or row["status"] == "settled":
                raise ValueError("Unknown reservation or already settled")
            tokens = (
                max(tokens, row["actual_tokens"] or 0)
                if tokens is not None
                else row["actual_tokens"]
            )
            cost = (
                max(cost, row["actual_cost"] or Decimal("0"))
                if cost is not None
                else row["actual_cost"]
            )
            status = "settled" if tokens is not None and cost is not None else "unknown"
            conn.execute(
                "UPDATE app.usage_records SET actual_tokens=%s,actual_cost=%s,status=%s "
                "WHERE id=%s",
                (tokens, cost, status, receipt_id),
            )
