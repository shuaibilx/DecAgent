"""Failures stay in the denominator and unknown/incomplete evidence cannot pass."""

import math
from collections import Counter
from decimal import Decimal
from statistics import median

from .schedule import STRATEGIES


def build_report(schedule, records, *, evidence_mode, metadata=None):
    metadata = metadata or {}
    expected = {t["id"]: t for t in schedule}
    rows = {r["id"]: r for r in records}
    if len(rows) != len(records) or any(key not in expected for key in rows):
        raise ValueError("Duplicate or unscheduled trial record")
    fingerprints = {row.get("fairness_digest") for row in records}
    if len(fingerprints) > 1:
        raise ValueError("Trial fairness information differs across strategies")
    for row in records:
        for key in ("machine_seconds", "human_wait_seconds"):
            value = row.get(key, 0)
            if type(value) not in {int, float} or not math.isfinite(value) or value < 0:
                raise ValueError("Trial duration must be finite and nonnegative")
        for key in (
            "calls",
            "tokens",
            "forbidden_writes",
            "confirmations",
            "clarifications",
            "fallbacks",
        ):
            value = row.get(key, 0)
            if type(value) is not int or value < 0:
                raise ValueError("Trial counters must be nonnegative integers")
    strategies = {}
    for strategy in STRATEGIES:
        planned = [t for t in schedule if t["strategy"] == strategy]
        observed = [rows[t["id"]] for t in planned if t["id"] in rows]
        for row in observed:
            if any(
                row.get(k) != expected[row["id"]][k]
                for k in ("case_id", "strategy", "round", "kind")
            ):
                raise ValueError("Trial identity differs from frozen schedule")
        common = [
            float(r["machine_seconds"])
            for r in observed
            if r["kind"] == "common" and r.get("attempted")
        ]
        count = len(planned)
        successes = sum(r.get("correct") is True for r in observed)
        strategies[strategy] = {
            "denominator": count,
            "correct": successes,
            "accuracy": successes / count if count else None,
            "attempted": sum(r.get("attempted") is True for r in observed),
            "failed_or_incorrect": count - successes,
            "states": dict(Counter(r.get("state", "unknown") for r in observed)),
            "confirmations": sum(r.get("confirmations", 0) for r in observed),
            "clarifications": sum(r.get("clarifications", 0) for r in observed),
            "fallbacks": sum(r.get("fallbacks", 0) for r in observed),
            "calls": sum(r.get("calls", 0) for r in observed),
            "cli_calls": sum(len(r.get("cli_calls", [])) for r in observed),
            "tokens": sum(r.get("tokens", 0) for r in observed),
            "known_cost_usd": str(
                sum((Decimal(str(r.get("cost_usd") or 0)) for r in observed), Decimal(0))
            ),
            "unknown_usage_trials": sum(r.get("usage_complete") is not True for r in observed),
            "forbidden_writes": sum(r.get("forbidden_writes", 0) for r in observed),
            "common_machine_p50_seconds": median(common) if common else None,
            "total_machine_seconds": sum(float(r.get("machine_seconds", 0)) for r in observed),
            "human_wait_seconds": sum(float(r.get("human_wait_seconds", 0)) for r in observed),
        }
    main, hybrid = strategies["main"], strategies["hybrid"]
    complete = (
        bool(schedule)
        and len(rows) == len(schedule)
        and all(
            r.get("attempted") is True
            and r.get("state")
            not in {"paused_budget", "not_run", "recovering", "running", "queued"}
            for r in rows.values()
        )
    )
    known = all(r.get("usage_complete") is True for r in rows.values())
    main_p50, hybrid_p50 = (s["common_machine_p50_seconds"] for s in (main, hybrid))
    checks = {
        "no_stop_reason": metadata.get("stop_reason") is None,
        "cumulative_jev_ledger_safe": not metadata.get("global_jev_ledger")
        or (
            metadata["global_jev_ledger"].get("blocked_unknown_or_pending") is False
            and metadata["global_jev_ledger"].get("within_cap") is True
        ),
        "live_evidence": evidence_mode == "live"
        and all(r.get("evidence_mode") == "live" for r in rows.values()),
        "complete": complete,
        "usage_known": known,
        "accuracy_not_lower": main["accuracy"] is not None
        and hybrid["accuracy"] is not None
        and hybrid["accuracy"] >= main["accuracy"],
        "forbidden_writes_zero": all(s["forbidden_writes"] == 0 for s in strategies.values()),
        "common_machine_p50_lower": main_p50 is not None
        and hybrid_p50 is not None
        and hybrid_p50 < main_p50,
        "mixed_total_machine_not_higher": hybrid["total_machine_seconds"]
        <= main["total_machine_seconds"],
    }
    return {
        "schema_version": "business-evaluation-report-1",
        "evidence_mode": evidence_mode,
        "metadata": metadata,
        "planned_trials": len(schedule),
        "missing_trials": len(schedule) - len(rows),
        "unattempted_trials": [
            {**trial, "state": "not_run"} for trial in schedule if trial["id"] not in rows
        ],
        "strategies": strategies,
        "acceptance": {
            "status": "passed" if all(checks.values()) else "not_passed",
            "checks": checks,
        },
        "records": records,
    }
