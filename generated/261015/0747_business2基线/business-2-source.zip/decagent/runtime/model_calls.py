"""Every provider attempt reserves durable tokens and fees before a network request."""

from __future__ import annotations

import json
from dataclasses import dataclass
from decimal import Decimal
from uuid import uuid4

from decagent.models.primary import PrimaryRequestNotDispatched, PrimaryResponseRejected
from decagent.storage.budget import BudgetExceeded


@dataclass(frozen=True)
class TokenPrice:
    version: str
    input_per_million: Decimal
    output_per_million: Decimal

    def __post_init__(self):
        if not self.version or any(
            not rate.is_finite() or rate < 0
            for rate in (self.input_per_million, self.output_per_million)
        ):
            raise ValueError("Versioned, finite nonnegative token prices are required")

    def cost(self, input_tokens, output_tokens):
        return (
            self.input_per_million * input_tokens + self.output_per_million * output_tokens
        ) / Decimal(1_000_000)


class BudgetedPrimary:
    def __init__(
        self,
        model,
        ledger,
        *,
        price=None,
        max_output_tokens=2048,
        unknown_cost_reservation=None,
        before_dispatch=None,
    ):
        self.model, self.ledger, self.price = model, ledger, price
        self.max_output_tokens = max_output_tokens
        self.unknown_cost_reservation = unknown_cost_reservation
        self.before_dispatch = before_dispatch

    def respond(self, messages, *, stream=False):
        # UTF-8 bytes conservatively bound textual input plus tool-schema framing.
        payload = json.dumps(messages, ensure_ascii=False).encode()
        input_bound = len(payload) + max(16384, getattr(self.model, "schema_bytes", 0) + 4096)
        cost = (
            self.price.cost(input_bound, self.max_output_tokens)
            if self.price
            else (self.unknown_cost_reservation)
        )
        if cost is None:
            raise BudgetExceeded("Configure a price or explicit unknown-fee reservation")
        receipt = self.ledger.reserve(
            uuid4().hex, 1, "primary", input_bound + self.max_output_tokens, cost
        )
        try:
            if self.before_dispatch:
                self.before_dispatch()
        except Exception:
            self.ledger.settle(receipt, 0, Decimal("0"))  # No provider request was sent.
            raise
        try:
            result = self.model.respond(messages, stream=stream)
        except PrimaryRequestNotDispatched:
            self.ledger.settle(receipt, 0, Decimal("0"))
            raise
        except PrimaryResponseRejected as rejected:
            usage = rejected.usage
            actual_cost = (
                self.price.cost(usage.input_tokens, usage.output_tokens)
                if self.price is not None and usage is not None
                else None
            )
            self.ledger.settle(
                receipt, usage.total_tokens if usage is not None else None, actual_cost
            )
            raise
        except Exception:
            self.ledger.settle(receipt, None, None)
            raise
        usage = result.usage
        actual_cost = (
            self.price.cost(usage.input_tokens, usage.output_tokens)
            if (self.price and usage)
            else None
        )
        self.ledger.settle(receipt, usage.total_tokens if usage else None, actual_cost)
        return result


class LedgerAttemptBudget:
    """Bridge Jev's retry contract to the same task ledger as the primary model."""

    def __init__(
        self, ledger, *, reservation_usd, provider="jev", request_key=None, before_dispatch=None
    ):
        self.ledger = ledger
        self.reservation_usd = Decimal(str(reservation_usd))
        if not self.reservation_usd.is_finite() or self.reservation_usd <= 0:
            raise ValueError("Positive Jev fee reservation required")
        self.provider, self.request_key = provider, request_key or uuid4().hex
        self.receipts = {}
        self._active_key = None
        self.before_dispatch = before_dispatch

    def reserve(self, request, attempt):
        if self.before_dispatch:
            self.before_dispatch()
        if attempt == 1:
            self._active_key = f"{self.request_key}:{uuid4().hex}"
            self.receipts = {}
        tokens = len(json.dumps(request.to_wire(""), ensure_ascii=False).encode()) + 4096
        try:
            receipt = self.ledger.reserve(
                self._active_key, attempt, self.provider, tokens, self.reservation_usd
            )
        except BudgetExceeded:
            return None
        self.receipts[attempt] = receipt
        try:
            if self.before_dispatch:
                self.before_dispatch()
        except Exception:
            self.ledger.settle(receipt, 0, Decimal("0"))
            raise
        return float(self.reservation_usd)

    def settle(self, record):
        tokens = record.usage.input_tokens + record.usage.output_tokens if record.usage else None
        cost = Decimal(str(record.cost_usd)) if record.cost_usd is not None else None
        self.ledger.settle(self.receipts[record.attempt], tokens, cost)
